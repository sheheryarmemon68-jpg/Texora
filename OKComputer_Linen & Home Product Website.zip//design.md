# Linen E-commerce Website - Design Style Guide

## Design Philosophy

### Brand Essence
**Natural Elegance**: Capturing the organic beauty and tactile quality of linen through sophisticated, understated design that speaks to conscious consumers who value both style and sustainability.

**Sustainable Luxury**: Positioning linen as a premium choice that combines environmental responsibility with timeless aesthetic appeal.

**Artisanal Craftsmanship**: Celebrating the traditional textile heritage while embracing modern e-commerce functionality.

### Color Palette
**Primary Colors**:
- Warm Linen (#F5F1E8) - Main background, representing natural linen fiber
- Sage Green (#9CAF88) - Accent color for sustainability messaging
- Charcoal (#2C2C2C) - Primary text and navigation elements
- Soft Cream (#FEFCF7) - Card backgrounds and content areas

**Secondary Colors**:
- Dusty Rose (#D4A5A5) - Gentle accent for feminine products
- River Blue (#7A9CC6) - Calming accent for home collection
- Terracotta (#C17B5A) - Warm accent for autumn collections

**Neutral Grays**:
- Light Gray (#F8F8F8) - Subtle backgrounds
- Medium Gray (#8B8B8B) - Secondary text
- Dark Gray (#4A4A4A) - Borders and dividers

### Typography
**Display Font**: Canela (serif) - For headings, hero text, and brand elements
- Elegant, editorial quality
- Strong personality for luxury positioning
- Excellent readability at large sizes

**Body Font**: Suisse International (sans-serif) - For body text, navigation, and UI elements
- Clean, modern, highly legible
- Neutral character that complements Canela
- Excellent for digital interfaces

**Font Hierarchy**:
- H1: Canela, 48px, Charcoal
- H2: Canela, 36px, Charcoal
- H3: Suisse International, 24px, Medium weight
- Body: Suisse International, 16px, Regular
- Caption: Suisse International, 14px, Light

## Visual Language

### Layout Principles
**Grid System**: 12-column responsive grid with 24px gutters
**Spacing**: 8px base unit system (8, 16, 24, 32, 48, 64px)
**Content Width**: Maximum 1200px for optimal reading experience
**Margins**: 5% on mobile, 3% on desktop

### Visual Hierarchy
**Information Architecture**:
1. Hero/Brand Message (emotional connection)
2. Product Categories (clear navigation)
3. Featured Collections (conversion focus)
4. Sustainability Story (brand values)
5. Social Proof (trust building)

### Image Treatment
**Photography Style**:
- Natural lighting with soft shadows
- Lifestyle-focused imagery showing linen in use
- Neutral backgrounds that don't compete with products
- Consistent color grading with warm, organic tones

**Product Photography**:
- Clean, minimal backgrounds
- Multiple angles showing texture and drape
- Lifestyle shots demonstrating scale and use
- Consistent lighting and color balance

## Visual Effects & Animation

### Core Libraries Integration
**Anime.js**: Smooth micro-interactions and element transitions
- Subtle fade-ins for product cards
- Smooth hover transitions on buttons
- Elegant page transitions

**ECharts.js**: Sustainability data visualization
- Water usage comparisons
- Carbon footprint metrics
- Interactive impact calculators

**Splide.js**: Product image carousels and testimonials
- Smooth image galleries
- Auto-playing hero banners
- Touch-friendly navigation

**p5.js**: Creative background effects
- Subtle particle systems representing linen fibers
- Organic shape animations
- Interactive hover effects

### Header & Navigation Effects
**Sticky Navigation**: Smooth opacity transition on scroll
**Logo Animation**: Subtle scale and color transition
**Menu Transitions**: Slide-in effects with staggered item animation

### Product Interaction Effects
**Hover States**: 
- Gentle lift with soft shadow (2px to 8px)
- Image zoom (105% scale)
- Color overlay with sustainability messaging

**Loading States**:
- Skeleton screens for product grids
- Progressive image loading with blur-to-sharp transition
- Smooth spinner animations

### Scroll Animations
**Reveal Animations**: Elements fade in when 30% visible
**Parallax Effects**: Subtle background movement (max 5%)
**Stagger Effects**: Product cards animate in sequence

## Component Design

### Buttons
**Primary Button**: Sage green background, white text, 8px border radius
**Secondary Button**: Transparent with sage green border, charcoal text
**Ghost Button**: Transparent with charcoal border, charcoal text

### Cards
**Product Cards**: 
- Soft white background with subtle shadow
- 12px border radius
- Hover lift effect
- Consistent aspect ratios for images

**Content Cards**:
- Clean white background
- 8px border radius
- Minimal border (1px, light gray)

### Forms
**Input Fields**:
- Clean borders with sage green focus states
- Generous padding (16px)
- Clear labels and helper text
- Error states in muted red

### Icons
**Style**: Minimal line icons
**Weight**: 1.5px stroke
**Color**: Charcoal for primary, sage green for active states

## Responsive Design

### Breakpoints
- Mobile: 320px - 768px
- Tablet: 768px - 1024px
- Desktop: 1024px+

### Mobile Adaptations
- Larger touch targets (44px minimum)
- Simplified navigation with hamburger menu
- Stacked layouts for better readability
- Optimized image sizes for faster loading

## Accessibility

### Color Contrast
- All text meets WCAG AA standards (4.5:1 minimum)
- Interactive elements have clear focus states
- Color is never the only way to convey information

### Typography
- Minimum 16px font size for body text
- Clear hierarchy with appropriate size differences
- Sufficient line height (1.5) for readability

## Brand Applications

### Logo Usage
- Primary: Full wordmark in charcoal
- Secondary: Icon-only version for small applications
- Minimum size: 120px width for wordmark

### Voice & Tone
**Professional yet Approachable**: Expert knowledge without intimidation
**Sustainability-Focused**: Environmental benefits woven throughout
**Quality-Conscious**: Emphasis on craftsmanship and longevity
**Inclusive**: Welcoming to all body types and style preferences