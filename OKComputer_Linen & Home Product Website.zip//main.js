// Pure Linen Co. - Main JavaScript File

// Global Variables
let cart = JSON.parse(localStorage.getItem('pureLinenCart')) || [];
let isCartOpen = false;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize all components
    initializeNavigation();
    initializeScrollAnimations();
    initializeParticles();
    initializeProductCarousel();
    updateCartDisplay();
    
    // Page-specific initializations
    const currentPage = getCurrentPage();
    switch(currentPage) {
        case 'products':
            initializeProductFilters();
            initializeQuickView();
            break;
        case 'cart':
            initializeCartPage();
            break;
        case 'about':
            initializeSustainabilityCharts();
            break;
    }
}

function getCurrentPage() {
    const path = window.location.pathname;
    if (path.includes('products.html')) return 'products';
    if (path.includes('cart.html')) return 'cart';
    if (path.includes('about.html')) return 'about';
    return 'home';
}

// Navigation Functions
function initializeNavigation() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Scroll Animations
function initializeScrollAnimations() {
    const revealElements = document.querySelectorAll('.reveal');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    revealElements.forEach(element => {
        revealObserver.observe(element);
    });
}

// Floating Particles Animation
function initializeParticles() {
    const particlesContainer = document.getElementById('particles');
    if (!particlesContainer) return;
    
    function createParticle() {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 20 + 's';
        particle.style.animationDuration = (15 + Math.random() * 10) + 's';
        particlesContainer.appendChild(particle);
        
        // Remove particle after animation
        setTimeout(() => {
            if (particle.parentNode) {
                particle.parentNode.removeChild(particle);
            }
        }, 25000);
    }
    
    // Create initial particles
    for (let i = 0; i < 15; i++) {
        setTimeout(createParticle, i * 1000);
    }
    
    // Continue creating particles
    setInterval(createParticle, 2000);
}

// Product Carousel
function initializeProductCarousel() {
    const carousel = document.getElementById('product-carousel');
    if (!carousel) return;
    
    new Splide(carousel, {
        type: 'loop',
        perPage: 3,
        perMove: 1,
        gap: '2rem',
        autoplay: true,
        interval: 4000,
        pauseOnHover: true,
        breakpoints: {
            1024: {
                perPage: 2,
            },
            640: {
                perPage: 1,
            }
        }
    }).mount();
}

// Cart Management
function addToCart(productId, productName, price, size = null, color = null) {
    const existingItem = cart.find(item => item.id === productId && item.size === size && item.color === color);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: productId,
            name: productName,
            price: price,
            size: size,
            color: color,
            quantity: 1,
            image: getProductImage(productId)
        });
    }
    
    saveCart();
    updateCartDisplay();
    showCartNotification(productName);
}

function removeFromCart(productId, size = null, color = null) {
    cart = cart.filter(item => !(item.id === productId && item.size === size && item.color === color));
    saveCart();
    updateCartDisplay();
    
    // Update cart page if currently viewing
    if (getCurrentPage() === 'cart') {
        displayCartItems();
    }
}

function updateCartQuantity(productId, size, color, newQuantity) {
    const item = cart.find(item => item.id === productId && item.size === size && item.color === color);
    if (item) {
        if (newQuantity <= 0) {
            removeFromCart(productId, size, color);
        } else {
            item.quantity = newQuantity;
            saveCart();
            updateCartDisplay();
            
            // Update cart page if currently viewing
            if (getCurrentPage() === 'cart') {
                displayCartItems();
            }
        }
    }
}

function getProductImage(productId) {
    const imageMap = {
        'pants-classic': 'https://kimi-web-img.moonshot.cn/img/www.merricksart.com/a5f04e02a734cb01242bfe62123665301f41707f.jpg',
        'shirt-essential': 'https://kimi-web-img.moonshot.cn/img/www.camixa.com/3dd16ba6aac1109097a39bc97f1f07d74d09c711.jpg',
        'bedding-set': 'https://kimi-web-img.moonshot.cn/img/www.papernstitchblog.com/4f03db0480362defb9767454b5149f246ae09ecc.jpg',
        'dress-flowing': 'https://kimi-web-img.moonshot.cn/img/leannebarlow.com/1e93d5cfba789ba9a627431197a905a7cc92851e.jpg'
    };
    return imageMap[productId] || 'resources/linen-texture-closeup.jpg';
}

function saveCart() {
    localStorage.setItem('pureLinenCart', JSON.stringify(cart));
}

function updateCartDisplay() {
    const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    const cartCountElements = document.querySelectorAll('#cart-count, #mobile-cart-count');
    
    cartCountElements.forEach(element => {
        if (cartCount > 0) {
            element.textContent = cartCount;
            element.classList.remove('hidden');
        } else {
            element.classList.add('hidden');
        }
    });
}

function showCartNotification(productName) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'fixed top-20 right-4 bg-sage-green text-white px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300';
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <span>Added ${productName} to cart</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Product Filtering (for products page)
function initializeProductFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const sortSelect = document.getElementById('sort-select');
    const searchInput = document.getElementById('search-input');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const category = this.dataset.category;
                filterProducts(category);
            });
        });
    }
    
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortProducts(this.value);
        });
    }
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            searchProducts(this.value);
        });
    }
}

function filterProducts(category) {
    const products = document.querySelectorAll('.product-card');
    
    products.forEach(product => {
        if (category === 'all' || product.dataset.category === category) {
            product.style.display = 'block';
            // Animate in
            setTimeout(() => {
                product.style.opacity = '1';
                product.style.transform = 'translateY(0)';
            }, 100);
        } else {
            // Animate out
            product.style.opacity = '0';
            product.style.transform = 'translateY(20px)';
            setTimeout(() => {
                product.style.display = 'none';
            }, 300);
        }
    });
}

function sortProducts(sortBy) {
    const productGrid = document.getElementById('product-grid');
    const products = Array.from(document.querySelectorAll('.product-card'));
    
    products.sort((a, b) => {
        switch(sortBy) {
            case 'price-low':
                return parseInt(a.dataset.price) - parseInt(b.dataset.price);
            case 'price-high':
                return parseInt(b.dataset.price) - parseInt(a.dataset.price);
            case 'name':
                return a.dataset.name.localeCompare(b.dataset.name);
            default:
                return 0;
        }
    });
    
    // Re-append sorted products
    products.forEach(product => {
        productGrid.appendChild(product);
    });
}

function searchProducts(query) {
    const products = document.querySelectorAll('.product-card');
    const searchTerm = query.toLowerCase();
    
    products.forEach(product => {
        const name = product.dataset.name.toLowerCase();
        const description = product.dataset.description.toLowerCase();
        
        if (name.includes(searchTerm) || description.includes(searchTerm)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// Quick View Modal
function initializeQuickView() {
    const quickViewButtons = document.querySelectorAll('.quick-view-btn');
    const modal = document.getElementById('quick-view-modal');
    const closeModal = document.getElementById('close-modal');
    
    if (quickViewButtons.length > 0 && modal) {
        quickViewButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.dataset.productId;
                openQuickView(productId);
            });
        });
        
        closeModal.addEventListener('click', function() {
            modal.classList.add('hidden');
        });
        
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.add('hidden');
            }
        });
    }
}

function openQuickView(productId) {
    const modal = document.getElementById('quick-view-modal');
    const productData = getProductData(productId);
    
    if (modal && productData) {
        // Update modal content
        document.getElementById('modal-product-image').src = productData.image;
        document.getElementById('modal-product-name').textContent = productData.name;
        document.getElementById('modal-product-price').textContent = `$${productData.price}`;
        document.getElementById('modal-product-description').textContent = productData.description;
        
        // Update add to cart button
        const addToCartBtn = document.getElementById('modal-add-to-cart');
        addToCartBtn.onclick = () => {
            const selectedSize = document.querySelector('input[name="size"]:checked')?.value;
            const selectedColor = document.querySelector('input[name="color"]:checked')?.value;
            
            addToCart(productId, productData.name, productData.price, selectedSize, selectedColor);
            modal.classList.add('hidden');
        };
        
        modal.classList.remove('hidden');
    }
}

function getProductData(productId) {
    const products = {
        'pants-classic': {
            name: 'Classic Linen Pants',
            price: 89,
            image: 'https://kimi-web-img.moonshot.cn/img/www.merricksart.com/a5f04e02a734cb01242bfe62123665301f41707f.jpg',
            description: 'Effortless elegance meets everyday comfort in these classic linen pants. Perfect for any occasion.'
        },
        'shirt-essential': {
            name: 'Essential Linen Shirt',
            price: 75,
            image: 'https://kimi-web-img.moonshot.cn/img/www.camixa.com/3dd16ba6aac1109097a39bc97f1f07d74d09c711.jpg',
            description: 'Your perfect everyday companion. Breathable, comfortable, and effortlessly stylish.'
        }
        // Add more products as needed
    };
    
    return products[productId];
}

// Cart Page Functions
function initializeCartPage() {
    displayCartItems();
    initializeCheckoutForm();
}

function displayCartItems() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartSummary = document.getElementById('cart-summary');
    
    if (!cartItemsContainer) return;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="text-center py-12">
                <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-1.5 6M7 13l-1.5 6m0 0h9m-9 0V19a2 2 0 002 2h7a2 2 0 002-2v-4"></path>
                </svg>
                <h3 class="text-xl font-semibold text-gray-900 mb-2">Your cart is empty</h3>
                <p class="text-gray-600 mb-6">Discover our beautiful linen collection</p>
                <a href="products.html" class="btn-primary px-6 py-3 rounded-full font-medium">
                    Start Shopping
                </a>
            </div>
        `;
        return;
    }
    
    let cartHTML = '';
    let subtotal = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        
        cartHTML += `
            <div class="flex items-center space-x-4 py-6 border-b border-gray-200">
                <img src="${item.image}" alt="${item.name}" class="w-20 h-20 object-cover rounded-lg">
                <div class="flex-1">
                    <h4 class="font-semibold text-lg">${item.name}</h4>
                    <p class="text-gray-600">$${item.price}</p>
                    ${item.size ? `<p class="text-sm text-gray-500">Size: ${item.size}</p>` : ''}
                    ${item.color ? `<p class="text-sm text-gray-500">Color: ${item.color}</p>` : ''}
                </div>
                <div class="flex items-center space-x-3">
                    <button onclick="updateCartQuantity('${item.id}', '${item.size}', '${item.color}', ${item.quantity - 1})" 
                            class="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path>
                        </svg>
                    </button>
                    <span class="w-8 text-center">${item.quantity}</span>
                    <button onclick="updateCartQuantity('${item.id}', '${item.size}', '${item.color}', ${item.quantity + 1})" 
                            class="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                    </button>
                </div>
                <div class="text-right">
                    <p class="font-semibold text-lg">$${itemTotal}</p>
                    <button onclick="removeFromCart('${item.id}', '${item.size}', '${item.color}')" 
                            class="text-red-500 hover:text-red-700 text-sm mt-1">
                        Remove
                    </button>
                </div>
            </div>
        `;
    });
    
    const tax = subtotal * 0.08; // 8% tax
    const shipping = subtotal > 100 ? 0 : 15; // Free shipping over $100
    const total = subtotal + tax + shipping;
    
    cartItemsContainer.innerHTML = cartHTML;
    
    if (cartSummary) {
        cartSummary.innerHTML = `
            <div class="bg-gray-50 rounded-lg p-6">
                <h3 class="font-semibold text-lg mb-4">Order Summary</h3>
                <div class="space-y-2 mb-4">
                    <div class="flex justify-between">
                        <span>Subtotal</span>
                        <span>$${subtotal.toFixed(2)}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Tax</span>
                        <span>$${tax.toFixed(2)}</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Shipping</span>
                        <span>${shipping === 0 ? 'Free' : '$' + shipping.toFixed(2)}</span>
                    </div>
                    <hr class="my-2">
                    <div class="flex justify-between font-semibold text-lg">
                        <span>Total</span>
                        <span>$${total.toFixed(2)}</span>
                    </div>
                </div>
                <button onclick="proceedToCheckout()" class="w-full btn-primary py-3 rounded-full font-medium">
                    Proceed to Checkout
                </button>
            </div>
        `;
    }
}

function initializeCheckoutForm() {
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault();
            processOrder();
        });
    }
}

function proceedToCheckout() {
    // Show checkout form or redirect to checkout page
    const checkoutSection = document.getElementById('checkout-section');
    if (checkoutSection) {
        checkoutSection.classList.remove('hidden');
        checkoutSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function processOrder() {
    // Simulate order processing
    const orderNumber = 'PL' + Date.now().toString().slice(-6);
    
    // Clear cart
    cart = [];
    saveCart();
    updateCartDisplay();
    
    // Show success message
    const successMessage = document.createElement('div');
    successMessage.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    successMessage.innerHTML = `
        <div class="bg-white rounded-lg p-8 max-w-md mx-4 text-center">
            <svg class="w-16 h-16 text-sage-green mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <h3 class="text-2xl font-semibold mb-4">Order Confirmed!</h3>
            <p class="text-gray-600 mb-4">Thank you for your purchase. Your order number is:</p>
            <p class="font-mono text-lg font-semibold text-sage-green mb-6">${orderNumber}</p>
            <p class="text-sm text-gray-500 mb-6">You'll receive a confirmation email shortly.</p>
            <button onclick="this.parentElement.parentElement.remove()" 
                    class="btn-primary px-6 py-3 rounded-full font-medium">
                Continue Shopping
            </button>
        </div>
    `;
    
    document.body.appendChild(successMessage);
    
    // Redirect to home page after a delay
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 5000);
}

// Sustainability Charts (for about page)
function initializeSustainabilityCharts() {
    // This would initialize ECharts for sustainability metrics
    // Implementation would depend on the specific chart requirements
    console.log('Sustainability charts initialized');
}

// Newsletter Subscription
function subscribeNewsletter(event) {
    event.preventDefault();
    const email = document.getElementById('newsletter-email').value;
    
    // Simulate subscription
    const button = event.target.querySelector('button[type="submit"]');
    const originalText = button.textContent;
    
    button.textContent = 'Subscribing...';
    button.disabled = true;
    
    setTimeout(() => {
        button.textContent = 'Subscribed!';
        button.style.backgroundColor = 'var(--sage-green)';
        
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
            button.style.backgroundColor = '';
            document.getElementById('newsletter-email').value = '';
        }, 2000);
    }, 1000);
}

// Utility Functions
function formatPrice(price) {
    return `$${price.toFixed(2)}`;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Error Handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    // Could implement error reporting here
});

// Performance Optimization
window.addEventListener('load', function() {
    // Initialize any remaining components after full page load
    console.log('Page fully loaded');
});